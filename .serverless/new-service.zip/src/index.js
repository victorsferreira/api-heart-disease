const serverless = require('serverless-http');
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const isReachable = require('is-reachable');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/api', async (req, res) => {
    try {
        const isIt = await isReachable('ip-172-31-82-220.ec2.internal:5000');
        console.log("Is reachable: ", isIt);
        res.send(`Is reachable: ${isIt}`);
    } catch (e) {
        throw e;
    }
});

app.get('/foo', async (req, res) => {
    console.log(Date.now());

    res.send('Pong');
});

app.use((err, req, res) => {
    console.log(err.message);
    res.status(500).send(err.stack);
});

module.exports.handler = serverless(app);