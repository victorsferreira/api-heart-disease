export default class PredictionResponseBuilder {
    // predict() { }
    // healthcheck() { }
}