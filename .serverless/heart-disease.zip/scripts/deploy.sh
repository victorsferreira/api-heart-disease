#!/bin/bash

echo "Running depoy script"
serverless deploy -s $1